-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2017 at 11:17 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ict_hardware_inventory`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `admin_returned_pc_no`
-- (See below for the actual view)
--
CREATE TABLE `admin_returned_pc_no` (
`admin_returned_pc_no` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `curriculum_returned_pc_no`
-- (See below for the actual view)
--
CREATE TABLE `curriculum_returned_pc_no` (
`curriculum_returned_pc_no` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `departament`
--

CREATE TABLE `departament` (
  `id` int(3) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departament`
--

INSERT INTO `departament` (`id`, `name`) VALUES
(2, 'Admin'),
(3, 'ICT'),
(1, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `department_location`
--

CREATE TABLE `department_location` (
  `id` int(5) UNSIGNED NOT NULL,
  `department_id` int(3) UNSIGNED NOT NULL,
  `location_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department_location`
--

INSERT INTO `department_location` (`id`, `department_id`, `location_id`) VALUES
(5, 1, 4),
(6, 1, 5),
(7, 1, 7),
(1, 2, 1),
(2, 3, 2),
(3, 3, 3),
(4, 3, 6);

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

CREATE TABLE `device` (
  `id` int(6) UNSIGNED NOT NULL,
  `serial_no` varchar(255) NOT NULL,
  `manufacturer` varchar(100) NOT NULL,
  `model` varchar(255) NOT NULL,
  `device_type_id` int(4) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`id`, `serial_no`, `manufacturer`, `model`, `device_type_id`) VALUES
(1, 'X3894281G', 'Toshiba', 'Satellite Pro A10', 1),
(2, 'E61891H4S135748', 'Brother', 'HL 2700CN', 2),
(3, 'WO44942479', 'RM', 'Celeron 2.4Ghz 512MB', 3),
(4, 'DMW4ZC802479', 'RM', ' 17\"', 4),
(5, 'u3894281G', 'Dell', 'Inspiron 15 3000', 1),
(6, 'A61891H4S135748', 'HP ', 'DesignJet T120 24-in Printer', 2),
(7, 'BO44942479', 'Asus', 'ASUS VivoPC K20CD', 3),
(8, 'AO44942479', 'Asus', 'ASUS VivoPC K20CD', 3),
(9, ' DOW4ZC802479', 'Acer ', 'K Series K222HQL 21.5\" Full HD LED Monitor', 4),
(10, ' AOW4ZC802479', 'Acer ', 'K Series K222HQL 21.5\" Full HD LED Monitor', 4),
(11, 'T3894281G', 'Lenovo ', 'Thinkpad T430', 1),
(12, 'Y3894281G', 'Lenovo ', 'Thinkpad T430 ', 1),
(13, 'EO44942479', 'HP ', '280 G2 Small Form Factor PC', 3),
(14, ' Z3894281G', 'Toshiba', 'Satellite Pro A10', 1),
(15, ' W3894281G', 'Asus', 'X751SA', 1),
(16, 'CO44942479', 'HP', '280 G2 Small Form Factor PC', 3),
(17, 'X3894281A', 'Toshiba', ' Satellite Pro A10', 1),
(18, ' CMW4ZC802479', 'AOC ', 'e2270Swhn Full HD 21.5\" LED Monitor', 4),
(19, ' EMW4ZC802479', 'AOC ', 'e2270Swhn Full HD 21.5\" LED Monitor', 4),
(20, 'F61891H4S135748', 'EPSON', 'WorkForce WF-2750 All-in-One Inkjet Printer with Fax', 2),
(21, 'S3894281G', 'LENOVO ', 'IdeaPad 510 15.6\" Laptop - Black', 1),
(22, 'R3894281G', 'LENOVO ', 'IdeaPad 510 15.6\" Laptop - Black', 1),
(23, 'YO44942479', '\r\nACER ', 'Aspire XC-780', 3),
(24, 'ZO44942479', '\r\nACER ', 'Aspire XC-780', 3),
(25, ' IMW4ZC802479', 'SAMSUNG ', 'S24F356 Full HD 24\" LED Monitor', 4),
(26, ' JMW4ZC802479', 'SAMSUNG ', 'S24F356 Full HD 24\" LED Monitor', 4),
(27, 'X3894281C', 'Toshiba', ' Satellite Pro A10', 1),
(28, 'X3894281B', 'Toshiba', ' Satellite Pro A10', 1),
(29, 'G61891H4S135748', 'SAMSUNG', 'Xpress M2070W Wireless All-in-One Monochrome Laser Printer', 2),
(30, 'P3894281G', 'HP', ' Pavilion x360 15-bk150sa 15.6\" 2 in 1 - Silver', 1),
(31, 'O3894281G', 'HP', 'Pavilion x360 15-bk150sa 15.6\" 2 in 1 - Silver', 1),
(32, 'MO44942479', 'APPLE ', 'iMac 21.5\" (2015)', 3),
(33, 'NO44942479', 'APPLE ', 'iMac 21.5\" (2015)', 3),
(34, 'JO44942479', 'SAMSUNG ', 'SAMSUNG C22F390 Full HD 22\" Curved LED Monitor', 4),
(35, 'IO44942479', 'SAMSUNG ', 'C22F390 Full HD 22\" Curved LED Monitor', 4),
(36, ' O61891H4S135748', 'HP \r\n', 'OfficeJet Pro 8715 All-in-One Wireless Inkjet Printer with Fax\r\n', 2),
(37, ' P61891H4S135748', 'HP', 'OfficeJet Pro 8715 All-in-One Wireless Inkjet Printer with Fax\r\n', 2),
(38, 'A3894281G', 'HP ', 'Pavilion 15-au150sa 15.6\" Laptop - White', 1),
(39, 'B3894281G', 'HP ', 'Pavilion 15-au150sa 15.6\" Laptop - White', 1),
(40, 'C3894281G', 'HP ', ' Pavilion 15-au150sa 15.6\" Laptop - White', 1),
(41, 'D3894281G', 'HP ', 'Pavilion 15-au150sa 15.6\" Laptop - White', 1),
(42, 'E3894281G', 'HP', 'Pavilion 15-au150sa 15.6\" Laptop - White', 1),
(43, 'LO44942479', 'HP ', 'Pavilion 23-q105na Touchscreen All-in-One PC', 3),
(44, 'HO44942479', 'HP ', 'Pavilion 23-q105na Touchscreen All-in-One PC', 3),
(45, 'GO44942479', 'HP', 'Pavilion 23-q105na Touchscreen All-in-One PC', 3),
(46, 'OMW4ZC802479', 'ACER ', ' S1 Series S271HLCBID Full HD 27\" LED Monitor', 4),
(47, 'SMW4ZC802479', 'ACER ', 'S1 Series S271HLCBID Full HD 27\" LED Monitor', 4),
(48, 'JMW4ZC802479', 'ACER ', 'S1 Series S271HLCBID Full HD 27\" LED Monitor', 4),
(49, 'Z61891H4S135748', 'HP ', 'LaserJet Pro MFP M277dw All-in-One Wireless Laser Printer', 2),
(50, 'W61891H4S135748', 'HP ', 'LaserJet Pro MFP M277dw All-in-One Wireless Laser Printer', 2);

-- --------------------------------------------------------

--
-- Table structure for table `device_inventory`
--

CREATE TABLE `device_inventory` (
  `id` int(10) UNSIGNED NOT NULL,
  `device_registration_id` int(6) UNSIGNED NOT NULL,
  `purchase_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `guarantee` int(2) NOT NULL,
  `department_location_id` int(5) UNSIGNED NOT NULL,
  `supplier_id` int(5) UNSIGNED NOT NULL,
  `user_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device_inventory`
--

INSERT INTO `device_inventory` (`id`, `device_registration_id`, `purchase_date`, `guarantee`, `department_location_id`, `supplier_id`, `user_id`) VALUES
(1, 22, '2017-03-27 15:17:15', 3, 2, 1, 2),
(2, 23, '2017-03-27 15:17:15', 3, 3, 2, 3),
(3, 24, '2016-12-15 12:36:00', 3, 1, 2, 4),
(4, 25, '2017-03-27 15:17:15', 3, 2, 2, 5),
(5, 35, '2017-03-27 15:17:15', 3, 1, 1, 12),
(6, 38, '2017-03-27 15:17:15', 3, 1, 1, 10),
(7, 41, '2017-03-27 15:17:15', 3, 1, 1, 11),
(8, 42, '2015-11-29 17:28:23', 3, 1, 1, 13),
(9, 43, '2015-12-07 14:19:33', 2, 1, 1, 14),
(10, 44, '2015-12-20 06:28:00', 3, 1, 1, 15),
(11, 45, '2017-03-27 15:17:55', 3, 1, 2, 16),
(12, 46, '2017-03-27 15:17:55', 3, 2, 1, 17),
(13, 47, '2016-01-01 12:19:00', 2, 2, 2, 18),
(14, 48, '2017-03-27 15:17:55', 3, 2, 2, 19),
(15, 49, '2015-10-14 13:27:00', 2, 2, 2, 20),
(16, 50, '2016-03-08 13:27:00', 3, 2, 1, 21),
(17, 51, '2017-03-27 15:17:15', 3, 3, 2, 22),
(18, 52, '2017-03-27 15:17:15', 3, 3, 1, 23),
(19, 53, '2015-12-06 13:11:25', 1, 3, 1, 24),
(20, 54, '2017-03-27 15:17:15', 3, 3, 2, 25),
(21, 55, '2016-04-11 17:15:00', 3, 3, 2, 26),
(22, 56, '2014-10-05 09:21:00', 1, 3, 2, 27),
(23, 67, '2016-04-10 14:24:00', 3, 4, 1, 28),
(24, 68, '2016-09-14 12:29:00', 2, 4, 2, 29),
(25, 69, '2015-09-14 11:23:00', 2, 4, 2, 30),
(26, 190, '2015-10-12 10:20:00', 2, 4, 1, 31),
(27, 191, '2015-11-19 11:22:00', 2, 4, 1, 52),
(28, 192, '2015-06-20 13:29:00', 3, 4, 1, 53),
(29, 193, '2015-06-15 10:18:00', 1, 4, 1, 54),
(30, 194, '2015-11-24 11:25:00', 3, 5, 2, 55),
(31, 195, '2017-03-26 08:18:00', 2, 5, 2, 56),
(32, 196, '2016-02-07 12:49:00', 1, 5, 2, 57),
(33, 197, '2016-01-21 16:30:00', 1, 5, 1, 58),
(34, 198, '2015-11-01 17:30:00', 3, 5, 2, 59),
(35, 199, '2016-11-22 11:16:00', 2, 5, 2, 60),
(36, 200, '2016-10-16 12:51:00', 2, 5, 1, 61),
(37, 201, '2015-10-28 14:27:00', 2, 6, 1, 62),
(38, 202, '2016-09-18 10:27:00', 1, 6, 2, 63),
(39, 203, '2016-01-18 13:21:00', 1, 6, 2, 64),
(40, 204, '2016-10-24 13:26:46', 3, 6, 2, 65),
(41, 205, '2016-05-08 12:54:38', 1, 6, 1, 66),
(42, 206, '2014-07-16 15:29:00', 3, 6, 1, 67),
(43, 207, '2015-04-22 12:34:58', 3, 6, 1, 68),
(44, 208, '2017-03-27 15:17:55', 3, 7, 1, 69),
(45, 209, '2016-09-29 12:34:38', 2, 7, 2, 70),
(46, 210, '2017-03-27 15:17:55', 3, 7, 2, 71),
(47, 211, '2017-03-27 15:17:55', 3, 7, 2, 72),
(48, 212, '2017-03-27 15:17:55', 3, 7, 2, 73),
(49, 213, '2017-03-27 15:17:55', 3, 7, 1, 74),
(50, 215, '2017-03-27 15:17:55', 3, 7, 1, 75);

-- --------------------------------------------------------

--
-- Table structure for table `device_job`
--

CREATE TABLE `device_job` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` varchar(512) NOT NULL,
  `device_inventory_id` int(10) UNSIGNED NOT NULL,
  `issue_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `close_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `device_job_type_id` int(2) UNSIGNED NOT NULL,
  `next_check_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `status` varchar(50) NOT NULL,
  `user_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device_job`
--

INSERT INTO `device_job` (`id`, `description`, `device_inventory_id`, `issue_date`, `close_date`, `device_job_type_id`, `next_check_date`, `status`, `user_id`) VALUES
(1, 'This device has a problem with the video card', 1, '2017-01-20 11:50:00', '2017-01-22 11:50:00', 1, '2017-11-16 00:00:00', 'close', 2),
(2, 'This printer has a problem with the cartridge', 2, '2016-12-19 10:00:00', '2016-12-22 16:01:00', 2, '2017-11-16 00:00:00', 'close', 3),
(12, 'This device has a problem with the motherboard', 3, '2017-03-27 14:07:02', '2017-03-27 13:55:49', 3, '2017-11-16 00:00:00', 'close', 4),
(15, 'This device has a problem with the power cable', 1, '2017-03-02 11:21:32', '2017-03-02 12:21:32', 3, '2017-11-16 00:00:00', 'close', 2),
(17, 'This device has a problem with the power cable', 22, '2017-04-02 17:47:57', '2017-03-26 12:19:22', 3, '2017-11-16 00:00:00', 'close', 4),
(19, 'This device has a problem with the power cable', 4, '2017-03-27 14:54:05', '2016-05-01 11:50:00', 3, '2017-11-16 00:00:00', 'close', 5),
(25, 'This device has a problem with the video card', 1, '2016-09-19 11:36:00', '2016-09-25 11:36:00', 1, '2017-11-16 00:00:00', 'close', 2),
(27, 'This printer has a problem with the cartridge', 2, '2016-11-11 10:00:00', '2016-11-11 11:00:00', 2, '2017-11-16 00:00:00', 'close', 3),
(28, 'This device has a problem with the motherboard', 3, '2017-03-27 15:09:03', '2017-02-02 12:36:00', 4, '2017-11-16 00:00:00', 'close', 4),
(29, 'This device has a problem with the power cable', 4, '2016-03-27 14:57:38', '2016-03-09 12:36:00', 1, '2017-11-16 00:00:00', 'close', 5),
(30, 'This device has a problem with the power cable', 5, '2015-12-20 13:19:22', '2015-12-20 14:19:22', 3, '2017-11-16 00:00:00', 'close', 10),
(39, 'This device has a problem with the video card', 6, '2017-02-14 08:42:00', '2017-02-24 08:42:00', 1, '2017-11-16 00:00:00', 'close', 11),
(40, 'This printer has a problem with the cartridge', 7, '2016-12-23 12:36:00', '2016-12-23 14:36:00', 2, '2017-11-16 00:00:00', 'close', 12),
(41, 'This device has a problem with the motherboard', 28, '2017-03-27 15:07:35', '2016-06-22 13:50:00', 2, '2017-11-16 00:00:00', 'close', 29),
(42, 'This device has a problem with the power cable', 47, '2016-11-26 10:29:00', '2016-11-09 12:36:00', 1, '2017-11-16 00:00:00', 'close', 72);

-- --------------------------------------------------------

--
-- Table structure for table `device_job_type`
--

CREATE TABLE `device_job_type` (
  `id` int(2) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device_job_type`
--

INSERT INTO `device_job_type` (`id`, `type`) VALUES
(4, 'Periodic check'),
(1, 'Repair'),
(3, 'Return'),
(2, 'Upgrade');

-- --------------------------------------------------------

--
-- Stand-in structure for view `device_maintenance_history`
-- (See below for the actual view)
--
CREATE TABLE `device_maintenance_history` (
`job_description` varchar(512)
,`registration_code` varchar(255)
,`device_serial_number` varchar(255)
,`device_manufacturer` varchar(100)
,`device_model` varchar(255)
,`device_type` varchar(50)
,`issue_date` timestamp
,`close_date` timestamp
,`device_job_type` varchar(50)
,`job_status` varchar(50)
,`job_issuer` varchar(511)
);

-- --------------------------------------------------------

--
-- Table structure for table `device_registration`
--

CREATE TABLE `device_registration` (
  `id` int(6) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `device_id` int(6) UNSIGNED NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device_registration`
--

INSERT INTO `device_registration` (`id`, `code`, `device_id`, `date`) VALUES
(22, '1309', 1, '2016-03-15 12:36:00'),
(23, '1310', 2, '2016-03-15 12:36:00'),
(24, '1808', 3, '2016-12-15 12:36:00'),
(25, '1809', 4, '2016-12-22 12:36:00'),
(35, '1311', 5, '2015-05-18 10:19:41'),
(38, '1313', 6, '2015-10-15 07:42:00'),
(41, '1811', 7, '2015-12-24 12:36:00'),
(42, '1810', 8, '2015-11-30 17:28:23'),
(43, '1812', 9, '2015-12-08 14:19:33'),
(44, '1813', 10, '2015-12-21 06:28:00'),
(45, '1315', 11, '2016-01-20 13:32:14'),
(46, '1316', 12, '2016-03-22 14:26:22'),
(47, '1814', 13, '2016-01-04 12:19:00'),
(48, '1317', 14, '2016-06-16 12:19:00'),
(49, '1318', 15, '2015-10-15 13:27:00'),
(50, '1815', 16, '2016-03-10 13:27:00'),
(51, '1816', 18, '2016-01-12 14:25:00'),
(52, '1817', 19, '2016-02-09 13:36:00'),
(53, '1319', 20, '2015-12-07 13:11:25'),
(54, '1320', 21, '2016-07-20 12:10:00'),
(55, '1322', 22, '2016-04-12 17:15:00'),
(56, '1818', 23, '2014-10-06 09:21:00'),
(67, '1819', 24, '2016-04-11 14:24:00'),
(68, '1820', 25, '2016-09-15 12:29:00'),
(69, '1821', 26, '2015-09-15 11:23:00'),
(190, '1335', 29, '2015-10-13 10:20:00'),
(191, '1336', 30, '2015-11-20 11:22:00'),
(192, '1337', 31, '2015-06-21 13:29:00'),
(193, '1835', 32, '2015-06-18 10:18:00'),
(194, '1826', 33, '2015-11-25 11:25:00'),
(195, '1827', 34, '2017-03-27 08:18:00'),
(196, '1828', 35, '2016-02-08 12:49:00'),
(197, '1328', 36, '2016-01-29 16:30:00'),
(198, '1329', 37, '2015-11-02 17:30:00'),
(199, '1330', 38, '2016-11-23 11:16:00'),
(200, '1331', 39, '2016-10-17 12:51:00'),
(201, '1332', 40, '2015-10-29 14:27:00'),
(202, '1333', 41, '2016-09-19 10:27:00'),
(203, '1334', 42, '2016-01-19 13:21:00'),
(204, '1829', 43, '2016-10-25 13:26:46'),
(205, '1830', 44, '2016-05-09 12:54:38'),
(206, '1831', 45, '2014-07-17 15:29:00'),
(207, '1832', 46, '2015-04-21 12:34:58'),
(208, '1833', 47, '2016-09-30 15:31:52'),
(209, '1834', 48, '2016-09-30 12:34:38'),
(210, '1339', 49, '2016-01-11 15:38:00'),
(211, '1340', 50, '2016-01-27 10:29:00'),
(212, '1343', 17, '2016-11-15 15:29:00'),
(213, '1342', 27, '2016-02-26 13:48:59'),
(215, '1344', 28, '2016-10-14 15:52:11');

-- --------------------------------------------------------

--
-- Table structure for table `device_type`
--

CREATE TABLE `device_type` (
  `id` int(4) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device_type`
--

INSERT INTO `device_type` (`id`, `type`) VALUES
(3, 'Base Unit'),
(1, 'Laptop'),
(4, 'Monitor'),
(2, 'Printer');

-- --------------------------------------------------------

--
-- Stand-in structure for view `hardware_and_supplier_details`
-- (See below for the actual view)
--
CREATE TABLE `hardware_and_supplier_details` (
`registration_code` varchar(255)
,`serial_no` varchar(255)
,`manufacturer` varchar(100)
,`model` varchar(255)
,`type` varchar(50)
,`registration_date` timestamp
,`purchase_date` timestamp
,`guarantee` int(2)
,`supplier_code` varchar(255)
,`supplier_name` varchar(255)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `hardware_by_departments`
-- (See below for the actual view)
--
CREATE TABLE `hardware_by_departments` (
`total_devices_no` bigint(21)
,`department_name` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `hardware_location`
-- (See below for the actual view)
--
CREATE TABLE `hardware_location` (
`building_no` varchar(10)
,`floor_no` int(3)
,`room_no` varchar(30)
,`department_name` varchar(100)
,`registration_code` varchar(255)
,`serial_no` varchar(255)
,`manufacturer` varchar(100)
,`model` varchar(255)
,`type` varchar(50)
,`registration_date` timestamp
,`purchase_date` timestamp
,`guarantee` int(2)
);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(6) UNSIGNED NOT NULL,
  `building_no` varchar(10) NOT NULL,
  `floor_no` int(3) NOT NULL,
  `room_no` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `building_no`, `floor_no`, `room_no`) VALUES
(1, 'A1', 1, '122'),
(2, 'A2', 1, '122'),
(3, 'A3', 1, '123'),
(4, 'B3', 1, '123'),
(5, 'C3', 2, '223'),
(7, 'C3', 2, 'Library'),
(6, 'C3', 3, 'ICT room');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(5) UNSIGNED NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `code`, `name`) VALUES
(1, 'LFT', 'Limited Firm Technology'),
(2, 'RM', 'Random Manufacturer');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `department_id` int(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `first_name`, `last_name`, `department_id`) VALUES
(2, 'mitreaggh', 'Gheorghe', 'Mitrea', 2),
(3, 'mitreaga', 'Alex', 'Mitrea', 3),
(4, 'cirimpeiac', 'Andrei', 'Cirimpei', 1),
(5, 'mitreaaa', 'Alex', 'Mitrea', 3),
(10, 'Chituff', 'Florin', 'Chitu', 3),
(11, 'AlvezEE', 'Eric', 'Alvez', 3),
(12, 'FernandezGG', 'Gabriel', 'Fernandez', 3),
(13, 'CurcaAA', 'Andrei', 'Curca', 3),
(14, 'ChristacheAA', 'Adrian', 'Christache', 3),
(15, 'HoropociucSS', 'Samuel ', 'Horopciuc', 3),
(16, 'PacurarAA', 'Andrei', 'Pacurar', 3),
(17, 'BiticaCC', 'Catalin', 'Bitica', 3),
(18, 'VerbanMM', 'Mihai', 'Verban', 3),
(19, 'JohnSS', 'Smith', 'John', 3),
(20, 'McGregorAA', 'Andrew ', 'McGregor', 3),
(21, 'ArnoBB', 'Berni', 'Arno', 3),
(22, 'MasterPP', 'Paul', 'Master', 3),
(23, 'GregoryHH', 'Helen', 'Gregory', 3),
(24, 'McCartLL', 'Lenon', 'McCart', 3),
(25, 'SmithAA', 'Andrew', 'Smith', 3),
(26, 'MorrisonZZ', 'Zenit ', 'Morrison', 3),
(27, 'KualaBB', 'Bernard', 'Kuala', 3),
(28, 'Nichols', 'Matei', 'Nichols', 3),
(29, 'MitreaDD', 'Diana', 'Mitrea', 3),
(30, 'PopsMM', 'Michael', 'Pops', 3),
(31, 'MurrayMM', 'Marius', 'Murray', 3),
(52, 'AghtanOO', 'Oran', 'Aghtan', 1),
(53, 'StanleySS', 'Steve', 'Stanley', 1),
(54, 'MonauFF', 'Fanch', 'Monau', 1),
(55, 'IlanimMM', 'Monica', 'Ilanim', 1),
(56, 'GeritEE', 'Eugeniu', 'Gerit', 1),
(57, 'ManuelaBB', 'Beatrice', 'Manuela', 1),
(58, 'MoonDD', 'Day', 'Moon', 1),
(59, 'Albatros', 'Blue', 'Albatros', 1),
(60, 'SunNN', 'Nielsen', 'Sun', 1),
(61, 'GaniumOO', 'Orlando', 'Ganium', 1),
(62, 'IstranII', 'Ivan', 'Istran', 1),
(63, 'StarLL', 'Let', 'Star', 1),
(64, 'ZaraTT', 'Tania', 'Zara', 1),
(65, 'WutOO', 'Oana', 'Wutt', 1),
(66, 'SulivanSS', 'Sergiu', 'Sulivan', 1),
(67, 'EnachePP', 'Peter', 'Enache', 1),
(68, 'MarinescuAA', 'Adrian', 'Marinescu', 1),
(69, 'ZambianCC', 'Clara', 'Zambian', 1),
(70, 'MuratOO', 'Orhan', 'Murat', 1),
(71, 'LabaMM', 'Manuela', 'Laba', 1),
(72, 'MehicoUU', 'Ciudad', 'Mehico', 1),
(73, 'StenPP', 'Patrick', 'Sten', 1),
(74, 'AlbbertiMM', 'Manchester', 'Albberti', 1),
(75, 'BeckleyAA', 'Andre', 'Beckley', 2);

-- --------------------------------------------------------

--
-- Structure for view `admin_returned_pc_no`
--
DROP TABLE IF EXISTS `admin_returned_pc_no`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `admin_returned_pc_no`  AS  select count(`djob`.`id`) AS `admin_returned_pc_no` from (((((((`device_job` `djob` join `device_job_type` `djobtype` on((`djob`.`device_job_type_id` = `djobtype`.`id`))) join `device_inventory` `dinv` on((`djob`.`device_inventory_id` = `dinv`.`id`))) join `device_registration` `dreg` on((`dinv`.`device_registration_id` = `dreg`.`id`))) join `device` `dev` on((`dreg`.`device_id` = `dev`.`id`))) join `device_type` `dtype` on((`dev`.`device_type_id` = `dtype`.`id`))) join `department_location` `dloc` on((`dinv`.`department_location_id` = `dloc`.`id`))) join `departament` `depart` on((`dloc`.`department_id` = `depart`.`id`))) where ((`dtype`.`type` = 'Base Unit') and (`djobtype`.`type` = 'Return') and (`depart`.`name` <> 'Admin')) ;

-- --------------------------------------------------------

--
-- Structure for view `curriculum_returned_pc_no`
--
DROP TABLE IF EXISTS `curriculum_returned_pc_no`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `curriculum_returned_pc_no`  AS  select count(`djob`.`id`) AS `curriculum_returned_pc_no` from (((((((`device_job` `djob` join `device_job_type` `djobtype` on((`djob`.`device_job_type_id` = `djobtype`.`id`))) join `device_inventory` `dinv` on((`djob`.`device_inventory_id` = `dinv`.`id`))) join `device_registration` `dreg` on((`dinv`.`device_registration_id` = `dreg`.`id`))) join `device` `dev` on((`dreg`.`device_id` = `dev`.`id`))) join `device_type` `dtype` on((`dev`.`device_type_id` = `dtype`.`id`))) join `department_location` `dloc` on((`dinv`.`department_location_id` = `dloc`.`id`))) join `departament` `depart` on((`dloc`.`department_id` = `depart`.`id`))) where ((`dtype`.`type` = 'Base Unit') and (`djobtype`.`type` = 'Return') and (`depart`.`name` <> 'Admin')) ;

-- --------------------------------------------------------

--
-- Structure for view `device_maintenance_history`
--
DROP TABLE IF EXISTS `device_maintenance_history`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `device_maintenance_history`  AS  select `djob`.`description` AS `job_description`,`dreg`.`code` AS `registration_code`,`dev`.`serial_no` AS `device_serial_number`,`dev`.`manufacturer` AS `device_manufacturer`,`dev`.`model` AS `device_model`,`dtype`.`type` AS `device_type`,`djob`.`issue_date` AS `issue_date`,`djob`.`close_date` AS `close_date`,`djobtype`.`type` AS `device_job_type`,`djob`.`status` AS `job_status`,concat(`usr`.`first_name`,' ',`usr`.`last_name`) AS `job_issuer` from ((((((`device_job` `djob` join `device_job_type` `djobtype` on((`djob`.`device_job_type_id` = `djobtype`.`id`))) join `device_inventory` `dinv` on((`djob`.`device_inventory_id` = `dinv`.`id`))) join `device_registration` `dreg` on((`dinv`.`device_registration_id` = `dreg`.`id`))) join `device` `dev` on((`dreg`.`device_id` = `dev`.`id`))) join `device_type` `dtype` on((`dev`.`device_type_id` = `dtype`.`id`))) join `user` `usr` on((`djob`.`user_id` = `usr`.`id`))) ;

-- --------------------------------------------------------

--
-- Structure for view `hardware_and_supplier_details`
--
DROP TABLE IF EXISTS `hardware_and_supplier_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hardware_and_supplier_details`  AS  (select `dreg`.`code` AS `registration_code`,`dev`.`serial_no` AS `serial_no`,`dev`.`manufacturer` AS `manufacturer`,`dev`.`model` AS `model`,`dtype`.`type` AS `type`,`dreg`.`date` AS `registration_date`,`dinv`.`purchase_date` AS `purchase_date`,`dinv`.`guarantee` AS `guarantee`,`su`.`code` AS `supplier_code`,`su`.`name` AS `supplier_name` from ((((`device_inventory` `dinv` join `supplier` `su` on((`dinv`.`supplier_id` = `su`.`id`))) join `device_registration` `dreg` on((`dinv`.`device_registration_id` = `dreg`.`id`))) join `device` `dev` on((`dreg`.`device_id` = `dev`.`id`))) join `device_type` `dtype` on((`dev`.`device_type_id` = `dtype`.`id`)))) ;

-- --------------------------------------------------------

--
-- Structure for view `hardware_by_departments`
--
DROP TABLE IF EXISTS `hardware_by_departments`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hardware_by_departments`  AS  select count(`dinv`.`id`) AS `total_devices_no`,`depart`.`name` AS `department_name` from ((`device_inventory` `dinv` join `department_location` `dloc` on((`dinv`.`department_location_id` = `dloc`.`id`))) join `departament` `depart` on((`dloc`.`department_id` = `depart`.`id`))) group by `depart`.`name` ;

-- --------------------------------------------------------

--
-- Structure for view `hardware_location`
--
DROP TABLE IF EXISTS `hardware_location`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `hardware_location`  AS  select `loc`.`building_no` AS `building_no`,`loc`.`floor_no` AS `floor_no`,`loc`.`room_no` AS `room_no`,`depart`.`name` AS `department_name`,`dreg`.`code` AS `registration_code`,`dev`.`serial_no` AS `serial_no`,`dev`.`manufacturer` AS `manufacturer`,`dev`.`model` AS `model`,`dtype`.`type` AS `type`,`dreg`.`date` AS `registration_date`,`dinv`.`purchase_date` AS `purchase_date`,`dinv`.`guarantee` AS `guarantee` from ((((((`device_inventory` `dinv` join `device_registration` `dreg` on((`dinv`.`device_registration_id` = `dreg`.`id`))) join `device` `dev` on((`dreg`.`device_id` = `dev`.`id`))) join `device_type` `dtype` on((`dev`.`device_type_id` = `dtype`.`id`))) join `department_location` `dloc` on((`dinv`.`department_location_id` = `dloc`.`id`))) join `departament` `depart` on((`dloc`.`department_id` = `depart`.`id`))) join `location` `loc` on((`dloc`.`location_id` = `loc`.`id`))) order by `loc`.`building_no`,`loc`.`floor_no`,`loc`.`room_no` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departament`
--
ALTER TABLE `departament`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_departament_name` (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `department_location`
--
ALTER TABLE `department_location`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_department_location_deprtment_id_location_id` (`department_id`,`location_id`),
  ADD KEY `fk_department_location_location_id_idx` (`location_id`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_device_serial_no` (`serial_no`),
  ADD KEY `fk_device_device_type_id_idx` (`device_type_id`);

--
-- Indexes for table `device_inventory`
--
ALTER TABLE `device_inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_device_inventory_device_registration_id` (`device_registration_id`),
  ADD KEY `fk_device_inventory_department_location_id_idx` (`department_location_id`),
  ADD KEY `fk_device_inventory_supplier_id_idx` (`supplier_id`),
  ADD KEY `fk_device_inventory_user_id_idx` (`user_id`);

--
-- Indexes for table `device_job`
--
ALTER TABLE `device_job`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_device_job_device_job_type_id_idx` (`device_job_type_id`),
  ADD KEY `fk_device_job_user_id_idx` (`user_id`),
  ADD KEY `fk_device_job_device_registration_id_idx` (`device_inventory_id`);

--
-- Indexes for table `device_job_type`
--
ALTER TABLE `device_job_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_device_job_type_type` (`type`);

--
-- Indexes for table `device_registration`
--
ALTER TABLE `device_registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_device_registration_code` (`code`),
  ADD KEY `fk_device_registration_device_id_idx` (`device_id`);

--
-- Indexes for table `device_type`
--
ALTER TABLE `device_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_device_type_type` (`type`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_location_building_no` (`building_no`,`floor_no`,`room_no`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_supplier_code_name` (`code`,`name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_user_username` (`username`),
  ADD KEY `fk_user_department_id_idx` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departament`
--
ALTER TABLE `departament`
  MODIFY `id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `department_location`
--
ALTER TABLE `department_location`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `device`
--
ALTER TABLE `device`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `device_inventory`
--
ALTER TABLE `device_inventory`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `device_job`
--
ALTER TABLE `device_job`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `device_job_type`
--
ALTER TABLE `device_job_type`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `device_registration`
--
ALTER TABLE `device_registration`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;
--
-- AUTO_INCREMENT for table `device_type`
--
ALTER TABLE `device_type`
  MODIFY `id` int(4) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `department_location`
--
ALTER TABLE `department_location`
  ADD CONSTRAINT `fk_department_location_department_id` FOREIGN KEY (`department_id`) REFERENCES `departament` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_department_location_location_id` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `device`
--
ALTER TABLE `device`
  ADD CONSTRAINT `fk_device_device_type_id` FOREIGN KEY (`device_type_id`) REFERENCES `device_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `device_inventory`
--
ALTER TABLE `device_inventory`
  ADD CONSTRAINT `fk_device_inventory_department_location_id` FOREIGN KEY (`department_location_id`) REFERENCES `department_location` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_device_inventory_device_registration_id` FOREIGN KEY (`device_registration_id`) REFERENCES `device_registration` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_device_inventory_supplier_id` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_device_inventory_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `device_job`
--
ALTER TABLE `device_job`
  ADD CONSTRAINT `fk_device_job_device_inventory_id` FOREIGN KEY (`device_inventory_id`) REFERENCES `device_inventory` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_device_job_device_job_type_id` FOREIGN KEY (`device_job_type_id`) REFERENCES `device_job_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_device_job_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `device_registration`
--
ALTER TABLE `device_registration`
  ADD CONSTRAINT `fk_device_registration_device_id` FOREIGN KEY (`device_id`) REFERENCES `device` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_department_id` FOREIGN KEY (`department_id`) REFERENCES `departament` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
